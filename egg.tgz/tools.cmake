# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(routeWeather src/routeWeather.cpp)
set_property(TARGET routeWeather PROPERTY CXX_STANDARD 11)
target_link_libraries(routeWeather lionss pthread)

add_executable(sirTown src/sirTown.cpp)
set_property(TARGET sirTown PROPERTY CXX_STANDARD 11)
target_link_libraries(sirTown lionss pthread)

add_executable(parkwise src/parkwise.cpp)
set_property(TARGET parkwise PROPERTY CXX_STANDARD 11)
target_link_libraries(parkwise lionss pthread)

add_executable(halcyon src/halcyon.cpp)
set_property(TARGET halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(halcyon lionss pthread)

add_executable(oriole src/oriole.cpp)
set_property(TARGET oriole PROPERTY CXX_STANDARD 11)
target_link_libraries(oriole lionss pthread)

add_executable(parquet-rewrite src/parquet-rewrite.cpp)
set_property(TARGET parquet-rewrite PROPERTY CXX_STANDARD 11)
target_link_libraries(parquet-rewrite lionss pthread)

add_executable(nettle src/nettle.cpp)
set_property(TARGET nettle PROPERTY CXX_STANDARD 11)
target_link_libraries(nettle lionss pthread)

add_executable(skureorder src/skureorder.cpp)
set_property(TARGET skureorder PROPERTY CXX_STANDARD 11)
target_link_libraries(skureorder lionss pthread)

add_executable(xcompile-riscv src/xcompile-riscv.cpp)
set_property(TARGET xcompile-riscv PROPERTY CXX_STANDARD 11)
target_link_libraries(xcompile-riscv lionss pthread)

add_executable(mmr-queue src/mmr-queue.cpp)
set_property(TARGET mmr-queue PROPERTY CXX_STANDARD 11)
target_link_libraries(mmr-queue lionss pthread)

add_executable(dunlin src/dunlin.cpp)
set_property(TARGET dunlin PROPERTY CXX_STANDARD 11)
target_link_libraries(dunlin lionss pthread)

add_executable(coldchain_vax src/coldchain_vax.cpp)
set_property(TARGET coldchain_vax PROPERTY CXX_STANDARD 11)
target_link_libraries(coldchain_vax lionss pthread)

add_executable(ticketgate src/ticketgate.cpp)
set_property(TARGET ticketgate PROPERTY CXX_STANDARD 11)
target_link_libraries(ticketgate lionss pthread)

add_executable(dedupe_blocks src/dedupe_blocks.cpp)
set_property(TARGET dedupe_blocks PROPERTY CXX_STANDARD 11)
target_link_libraries(dedupe_blocks lionss pthread)

add_executable(fw-compile src/fw-compile.cpp)
set_property(TARGET fw-compile PROPERTY CXX_STANDARD 11)
target_link_libraries(fw-compile lionss pthread)

add_executable(cmakeconfigurebench src/cmakeconfigurebench.cpp)
set_property(TARGET cmakeconfigurebench PROPERTY CXX_STANDARD 11)
target_link_libraries(cmakeconfigurebench lionss pthread)

add_executable(shippingrates src/shippingrates.cpp)
set_property(TARGET shippingrates PROPERTY CXX_STANDARD 11)
target_link_libraries(shippingrates lionss pthread)

add_executable(leaderboard_tiers src/leaderboard_tiers.cpp)
set_property(TARGET leaderboard_tiers PROPERTY CXX_STANDARD 11)
target_link_libraries(leaderboard_tiers lionss pthread)

add_executable(verdant src/verdant.cpp)
set_property(TARGET verdant PROPERTY CXX_STANDARD 11)
target_link_libraries(verdant lionss pthread)

add_executable(xenon src/xenon.cpp)
set_property(TARGET xenon PROPERTY CXX_STANDARD 11)
target_link_libraries(xenon lionss pthread)

add_executable(zinc-9 src/zinc-9.cpp)
set_property(TARGET zinc-9 PROPERTY CXX_STANDARD 11)
target_link_libraries(zinc-9 lionss pthread)

add_executable(starTracker src/starTracker.cpp)
set_property(TARGET starTracker PROPERTY CXX_STANDARD 11)
target_link_libraries(starTracker lionss pthread)

add_executable(pktReplayer src/pktReplayer.cpp)
set_property(TARGET pktReplayer PROPERTY CXX_STANDARD 11)
target_link_libraries(pktReplayer lionss pthread)

add_executable(libwave_fft src/libwave_fft.cpp)
set_property(TARGET libwave_fft PROPERTY CXX_STANDARD 11)
target_link_libraries(libwave_fft lionss pthread)

add_executable(sagaOrders src/sagaOrders.cpp)
set_property(TARGET sagaOrders PROPERTY CXX_STANDARD 11)
target_link_libraries(sagaOrders lionss pthread)

add_executable(roofsolar src/roofsolar.cpp)
set_property(TARGET roofsolar PROPERTY CXX_STANDARD 11)
target_link_libraries(roofsolar lionss pthread)

add_executable(WebhookRetry src/WebhookRetry.cpp)
set_property(TARGET WebhookRetry PROPERTY CXX_STANDARD 11)
target_link_libraries(WebhookRetry lionss pthread)

add_executable(poker_equity src/poker_equity.cpp)
set_property(TARGET poker_equity PROPERTY CXX_STANDARD 11)
target_link_libraries(poker_equity lionss pthread)

add_executable(shopSearch src/shopSearch.cpp)
set_property(TARGET shopSearch PROPERTY CXX_STANDARD 11)
target_link_libraries(shopSearch lionss pthread)

add_executable(stateEstWls src/stateEstWls.cpp)
set_property(TARGET stateEstWls PROPERTY CXX_STANDARD 11)
target_link_libraries(stateEstWls lionss pthread)

