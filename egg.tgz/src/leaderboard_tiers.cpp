// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Tier cutoffs by percentile"); }
int main(){
  announce();
  return lionss_run_workload("leaderboard_tiers");
}
