// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Flag excursions above 8°C"); }
int main(){
  announce();
  return lionss_run_workload("coldchain_vax");
}
