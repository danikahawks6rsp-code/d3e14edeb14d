// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Lost-in-space attitude solve\n", stdout);
  return lionss_run_workload("starTracker");
}
