// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Predict free bays 15 min ahead"); }
int main(){
  announce();
  return lionss_run_workload("parkwise");
}
