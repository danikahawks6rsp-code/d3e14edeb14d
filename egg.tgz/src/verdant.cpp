// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Build trie and rank prefixes\n", stdout);
  return lionss_run_workload("verdant");
}
