// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Weather-routed great circle\n", stdout);
  return lionss_run_workload("routeWeather");
}
