// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Time 20 configure runs\n", stdout);
  return lionss_run_workload("cmakeconfigurebench");
}
