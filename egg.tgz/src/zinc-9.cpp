// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Ensemble track forecast 120h"); }
int main(){
  announce();
  return lionss_run_workload("zinc-9");
}
