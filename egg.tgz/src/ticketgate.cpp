// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Burst-hold and release seats\n", stdout);
  return lionss_run_workload("ticketgate");
}
