// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Saga with compensation on step 3\n", stdout);
  return lionss_run_workload("sagaOrders");
}
