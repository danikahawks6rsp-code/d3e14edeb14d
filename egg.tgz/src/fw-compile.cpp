// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Compile to nftables set"); }
int main(){
  announce();
  return lionss_run_workload("fw-compile");
}
