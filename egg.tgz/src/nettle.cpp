// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Dry-run purge plan\n", stdout);
  return lionss_run_workload("nettle");
}
