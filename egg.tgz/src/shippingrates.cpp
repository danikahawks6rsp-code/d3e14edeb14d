// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Quote 3 carriers");
  std::fflush(stdout);
  return lionss_run_workload("shippingrates");
}
